---
layout: default
permalink: "/"
---

## Scalatore di montagne all'alba,<br>videogiocatore nella notte.

Se volete fare un saluto o chiedere qualcosa potete scrivermi su [Telegram](https://t.me/kiritokitto), dove tengo un diario per raccontare aneddoti, pensieri o commenti sui giochi, film e anime che inizio. Test.

[**Diario di Kirito Kitto >**](https://t.me/+eYDpkG161AY4YzI0)

---

* [Year in Videogames](/year-in-videogames)
* [Into the Wilds](/into-the-wilds)
* [Tracker](/tracker)
* [Lavoro](/job)
* [Backloggd Profile](https://www.backloggd.com/u/KiritoKitto/)

---

*Con affetto, Kirito Kitto.*