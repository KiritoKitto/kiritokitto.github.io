---
layout: "default"
permalink: "/job"
---

# Lavoro

Attualmente lavoro come Data Analyst: ingegnerizzazione e manutenzione di metriche:

- Excel Solutions Engineer
- Onboarding Specialist
- Metrics Engineer

---

#### 2024
- Trainer & Speaker
- Metrics Engineer

#### 2023
- New Employee Technical Coach
- Data Analyst

#### 2022
- Trainer (Script Development & Speaker)
- Excel Expert
- Rebranding Support

#### 2021

- Microsoft Office Support

---

*Ultimo aggiornamento: Luglio 2025*