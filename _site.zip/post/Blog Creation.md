---
permalink: "/bc"
---

# Genesi della creazione di un blog personale

È da anni che mi incuriosisce l'idea di avere un piccolo blog personale. Questo sito è infatti solo uno dei tanti tentativi di avere un posto dove raccontare e raccogliere vari aneddoti.

Il primo game-changer è stato il **[Diario di Kirito Kitto](https://t.me/+eYDpkG161AY4YzI0)**, un canale Telegram aperto nel Giugno 2022 e che uso tuttora come diario. All'inizio parlavo solo di videogiochi, ma con il tempo ho iniziato a scrivere anche di altro (anche se il focus è rimasto quello originale).

---

Nei mesi successivi mi vennero in mente post più articolati, che richiedevano una formattazione più complessa. Inizialmente usai Telegraph, poi passai a Teletype e infine ho scoperto Bear Blog. 

Ho ideato questa grafica cercando di rimanere sul minimal e lanciato il sito in pochi giorni. È stato divertente e ci sarebbero decine di aneddoti al riguardo, ma sarà per un'altra volta.

As always, grazie per essere arrivato/a fino a qui. Spero che uscirai da questa pagina più ispirato/a di prima!

*Con affetto, Kirito Kitto*